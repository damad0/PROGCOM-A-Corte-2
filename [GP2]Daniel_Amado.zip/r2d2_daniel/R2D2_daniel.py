import pygame
import sys
from pygame import *
from pygame.locals import *
from random import randint

pygame.init()
tamaño = width, height = 700, 500
ventana = pygame.display.set_mode(tamaño)

fuente = pygame.font.SysFont("Arial", 20)
texto = fuente.render("Mueve a r2d2 con las flechas", 0, (0, 30, 50))

pygame.mixer.init()
sonido = pygame.mixer.Sound("r2d2.wav")

r2d2 = pygame.image.load("r2d2.png")
escala = (100, 90)
r2d2 = pygame.transform.scale(r2d2, escala)
X = 50
Y = 50

v = 20

c3po = pygame.image.load("c3po.png")
escalar = (100, 90)
c3po = pygame.transform.scale(c3po, escalar)
cx = 600
cy = 400

fondo = (255, 255, 255)

while True:

    ventana.fill(fondo)
    ventana.blit(c3po, (cx, cy))
    ventana.blit(r2d2, (X, Y))

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == K_RIGHT:
                X += v
                pygame.mixer.pause()
                pygame.mixer.Sound.play(sonido, -1)
            elif event.key == K_DOWN:
                Y += v
                pygame.mixer.pause()
                pygame.mixer.Sound.play(sonido, -1)
            elif event.key == K_UP:
                Y -= v
                pygame.mixer.pause()
                pygame.mixer.Sound.play(sonido, -1)
            elif event.key == K_LEFT:
                X -= v
                pygame.mixer.pause()
                pygame.mixer.Sound.play(sonido, -1)

    ventana.blit(texto, (0, 0))
    pygame.display.update()